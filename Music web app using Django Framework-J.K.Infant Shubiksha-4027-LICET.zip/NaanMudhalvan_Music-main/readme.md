python -m venv venv
.\venv\Scripts\activate
pip install django
